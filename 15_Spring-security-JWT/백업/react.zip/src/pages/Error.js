function Error() {

    return (
        <div>
            <h1>404 Error</h1>
        </div>
    );
}

export default Error;